// steam login button

<a href="<?php echo e(route('steam.login')); ?>" class="btn btn-primary">Login with Steam</a>
<?php /**PATH /var/www/html/resources/views/index.blade.php ENDPATH**/ ?>