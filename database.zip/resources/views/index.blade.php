// steam login button

<a href="{{ route('steam.login') }}" class="btn btn-primary">Login with Steam</a>
