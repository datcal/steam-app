<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Laravel\Socialite\Facades\Socialite;

class SteamAuthController extends Controller
{
    public function redirectToSteam()
    {
        return Socialite::driver('steam')->redirect();
    }

    public function handleSteamCallback()
    {
        $user = Socialite::driver('steam')->user();

        // Here, you can store or retrieve the user in your database and log them in.
    }
}
